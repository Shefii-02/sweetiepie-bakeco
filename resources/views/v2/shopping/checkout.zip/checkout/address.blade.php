<div class="row">
    <div class="col-lg-6">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="firstname" class="form-label">First Name<span class="text-danger">
                    *</span></label>
            <input value="{{ $firstname ?? null }}" placeholder="Enter your first name" type="text" autocomplete="off"
                class="form-control px-0 border-0 bg-white shadow-none" name="{{ $name }}_firstname"
                id="firstname" value="{{ old('firstname') }}">
            <span>
                {{ $errors->first('firstname') }}
            </span>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="lastname" class="form-label">Last Name</label>
            <input value="{{ $lastname ?? null }}" placeholder="Enter your last name" type="text" autocomplete="off"
                class="form-control px-0 border-0 bg-white shadow-none" name="{{ $name }}_lastname"
                id="lastname">
            <span>
                {{ $errors->first('lastname') }}
            </span>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="address" class="form-label">Address<span class="text-danger">
                    *</span></label>
            <textarea placeholder="Enter your address" class="form-control address_fill px-0 border-0 bg-white shadow-none"
                autocomplete="off" value="{{ old('address') }}" name="{{ $name }}_address" id="address">{{ $address ?? null }}</textarea>
            <span>
                {{ $errors->first('address') }}
            </span>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="city" class="form-label">City<span class="text-danger">
                    *</span></label>
            <input  value="{{ $city ?? null }}" placeholder="Enter your city" type="text" autocomplete="off"
                class="form-control city_fill px-0 border-0 bg-white shadow-none"
                value="{{ old('city') }}" name="{{ $name }}_city" id="city">
            <span>
                {{ $errors->first('city') }}
            </span>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="postal_code" class="form-label">Postal Code<span
                    class="text-danger"> *</span></label>
            <input  value="{{ $b_postal ?? null }}" placeholder="Enter your province" type="text" autocomplete="off"
                maxlength="7"
                class="form-control postal_fill px-0 border-0 bg-white shadow-none"
                id="postal_code" value="{{ old('b_postal') }}" name="{{ $name }}_postal">
            <span>
                {{ $errors->first('b_postal') }}
            </span>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="province" class="form-label">Province<span class="text-danger">
                    *</span></label>

            <select class="form-control province_fill px-0 border-0 bg-white shadow-none"
                name="{{ $name }}_province" id="province">
                <option value="">Select Province</option>
                @foreach ($provinces as $item)
                    <option  {{ ($province ?? null) == $item->name ? "selected" : '' }} value="{{ $item->name }}"
                        {{ $item->code == old('province') ? 'selected' : '' }}>
                        {{ $item->name }}</option>
                @endforeach
            </select>
            <span>
                {{ $errors->first('province') }}
            </span>

        </div>
    </div>
    <div class="col-lg-6">
        <div class="mb-3 theme-input-group bg-white p-2 rounded-1">
            <label for="phone" class="form-label">Phone<span
                    class="text-danger"> *</span></label>
            <input  value="{{ $b_phone ?? null }}" placeholder="Enter your phone" type="text" autocomplete="off"
                maxlength="7"
                class="form-control px-0 border-0 bg-white shadow-none"
                id="phone" value="{{ old('b_phone') }}" name="{{ $name }}_phone">
            <span>
                {{ $errors->first('b_phone') }}
            </span>
        </div>
    </div>
</div>