<html>
    <head>
        <title>Product Detail</title>
    </head>
    <body>
        
            <h1>{{$product->name}}</h1>
            <h3 id="selected-price">{{$product->product_variation->first()->price}}</h3>
            
            <ul>
                @foreach($options as $optionkey=>$option)
                    <li>{{$optionkey}}
                        <ul class="options">
                        @foreach($option as $subkey=>$suboption)
                            <li><label><input class="option" type="radio" name="{{$optionkey}}" value="{{$subkey}}"  data-variation-ids="{{implode(',',$suboption)}}" data-attr="{{$optionkey.':'.$subkey}}">{{$subkey}}</label></li>
                        @endforeach
                        </ul>
                    </li>
                @endforeach
            </ul>
            
            @foreach($product->product_variation as $variation)
                <input type="hidden" id="{{$variation->id}}" value="{{$variation->price}}" />
            @endforeach
            
            
            @dump($product->images)
            
            
            <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
            <script>
                
                $(document).ready(function(){
                    $(".options").each(function(){
                        $(this).find(".option").first().attr("checked","checked");
                    });
                    
                    function selectVariant() {
                        var choosen_vars = [];
                        
                        $(".options").each(function(){
                            $(this).find(".option").each(function(){
                                if($(this).is(":checked")) {
                                    var vars = $(this).attr("data-variation-ids");
                                    choosen_vars.push(vars.split(","));
                                }
                            })
                        });
                        
                        var final = choosen_vars[0];
                        
                        for(i=1;i<choosen_vars.length;i++) {
                            var final = $(final).filter(choosen_vars[i]);
                            
                        }
                        
                        var price = $("#"+final[0]).val();
                        console.log(final[0]);
                        console.log(price);
                        
                        
                        $("#selected-price").html(price)


                    }
                    
                    $(".option").click(function(){
                        selectVariant();
                    })
                    
                    selectVariant();
                    
                    
                })
                
            </script>
            
    </body>
</html>