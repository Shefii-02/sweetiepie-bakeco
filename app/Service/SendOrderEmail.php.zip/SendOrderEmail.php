<?php
namespace App\Service;
use App\Models\User;
use App\Models\Order;
use App\Models\Item;
use App\Models\Store;
use App\Models\Basket;
use Illuminate\Support\Facades\Mail;
use App\Mail\OrderInvoiceMail;

trait SendOrderEmail{

    public function SendEmailTrait(){
           
        $unsentCusEmails = Order::with('basket','orderItems','address')
                             ->whereHas('basket')
                             ->whereHas('address')
                             ->where('status',1)
                             ->where('customer_email_send',0)
                             ->get();
                             
        $unsentStoreEmails = Order::with('basket','orderItems','address')
                             ->whereHas('basket')
                             ->whereHas('address')
                             ->where('status',1)
                             ->where('store_email_send',0)
                             ->get();
                foreach($unsentCusEmails as $cusEmail){
                    //order Confirmation mail
                    $sendto = env('MAIL_TO_COPY');
                    try{
                        Mail::to($cusEmail->email)->bcc($sendto)->send(new OrderInvoiceMail($cusEmail));    
                       Order::where('id', $cusEmail->id)->update(['customer_email_send' => 1]);
                    }
                    catch(\Exception $e){
                        
                    }
                }
                
                foreach($unsentStoreEmails as $cusEmail){
                            //order notification
                    $cc_mailId = [];
                    $all_ordersSend= env('MAIL_TO_ORDER') ?? env('MAIL_FROM_ADDRESS'); 
                        if(env('APP_URL') != 'https://www.stage.mysweetiepie.ca11'){
                            if($store){
                                if($basket->order_type == 'delivery') {
                                    $cc_mailId[] = $store->email;    // Default Delivery store mail
                                }
                                else
                                {   
                                    // Selected Store mail 
                                    $cc_mailId[] = $store->email;  //primary mail id
                                    
                                    // if($store->secondary_email != ''){
                                        // $cc_mailId[] = $store->secondary_email; //secondary mail id
                                    // }
                                    if($store->secondary_email != ''){
                                        $sec_emails  = explode(',',$store->secondary_email);
                                        $cc_mailId  = array_merge($cc_mailId,$sec_emails);
                                    }
                                }
                            }  
                        }
                        if(count($cc_mailId) <= 0){
                            $cc_mailId[] = env('MAIL_TO_DEV'); 
                        }
                    try {
                        Mail::to($all_ordersSend)->bcc($cc_mailId)
                            ->send(new OrderNotification($order_details));
                        Order::where('id', $cusEmail->id)->update(['customer_email_send' => 1]);
                    }
                    catch(\Exception $e) {
                        
                    }
                }
                
      }
}